import { useEffect, useMemo, useRef, useState } from "react";
import {
  Container, Grid, TextField, FormControlLabel, Switch, Box,
  Pagination, Stack, Typography, CircularProgress, Alert, InputAdornment, Paper, Button,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import AppHeader from "../components/AppHeader";
import PartCard from "../components/PartCard";
import GearAnimation from "../components/GearAnimation";
import { fetchParts } from "../api";

const PAGE_SIZE = 24;

export default function CatalogPage() {
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [inStockOnly, setInStockOnly] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const catalogSectionRef = useRef(null);

  const pageCount = useMemo(() => Math.max(1, Math.ceil(total / PAGE_SIZE)), [total]);

  const scrollToCatalog = () => {
    catalogSectionRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  useEffect(() => {
    const timeout = setTimeout(() => {
      setSearch(searchInput);
      setPage(1);
    }, 400);
    return () => clearTimeout(timeout);
  }, [searchInput]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    fetchParts({ search, inStockOnly, page, pageSize: PAGE_SIZE })
      .then((data) => {
        if (cancelled) return;
        setItems(data.items);
        setTotal(data.total);
      })
      .catch(() => {
        if (!cancelled) setError("Не удалось загрузить каталог. Проверьте подключение к серверу.");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [search, inStockOnly, page]);

  return (
    <>
      <AppHeader />
      <Container maxWidth="lg" sx={{ py: { xs: 2, md: 5 }, px: { xs: 1.5, sm: 3 } }}>
        <Paper
          elevation={0}
          sx={{
            mb: 5,
            color: "#FFFFFF",
            background:
              "radial-gradient(circle at 88% 12%, rgba(175,211,234,0.14) 0%, transparent 34%), linear-gradient(118deg, #0F2740 0%, #1B3A5C 48%, #3D7CAE 100%)",
            borderRadius: { xs: 3.5, sm: 4.5 },
            position: "relative",
            overflow: "hidden",
            boxShadow: "0 18px 42px rgba(15,39,64,0.20)",
            display: "grid",
            gridTemplateColumns: { xs: "1fr", md: "1.15fr 0.85fr" },
            alignItems: "center",
            minHeight: { md: 480 },
          }}
        >
          <Box
            sx={{
              order: { xs: 2, md: 1 },
              position: "relative",
              zIndex: 1,
              p: { xs: 3, sm: 5, md: 7 },
              pr: { md: 2 },
            }}
          >
            <Typography
              component="h1"
              sx={{
                fontFamily: '"Oswald", sans-serif',
                textTransform: "uppercase",
                color: "#FFFFFF",
                mb: 2.5,
                fontWeight: 700,
                letterSpacing: "0.01em",
                fontSize: { xs: "2.1rem", sm: "2.7rem", md: "3.2rem" },
                lineHeight: 1.06,
              }}
            >
              Omegation — новые стандарты качества в автокомпонентах
            </Typography>
            <Typography
              sx={{
                color: "rgba(255,255,255,0.82)",
                mb: 4,
                maxWidth: 480,
                fontSize: { xs: "0.92rem", sm: "1.02rem" },
                lineHeight: 1.75,
              }}
            >
              Omegation — молодая и динамично развивающаяся компания, специализирующаяся на разработке
              и производстве автозапчастей для легковых и коммерческих автомобилей. Несмотря на
              недавнее основание, мы уже выстроили современную производственную и логистическую
              цепочку, позволяющую предлагать рынку один из самых широких и технологичных
              ассортиментов в своём сегменте.
            </Typography>

            <Button
              variant="contained"
              size="large"
              onClick={scrollToCatalog}
              endIcon={<ArrowDownwardIcon />}
              sx={{
                bgcolor: "#FFFFFF",
                color: "primary.main",
                fontWeight: 700,
                px: 3.5,
                py: 1.1,
                borderRadius: 999,
                boxShadow: "0 12px 28px rgba(2,12,25,0.26)",
                "&:hover": { bgcolor: "rgba(255,255,255,0.9)" },
              }}
            >
              Перейти к каталогу
            </Button>
          </Box>

          <Box
            sx={{
              order: { xs: 1, md: 2 },
              position: "relative",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              py: { xs: 3, md: 0 },
              minHeight: { xs: 220, md: "100%" },
              "&::before": {
                content: '""',
                position: "absolute",
                inset: 0,
                background:
                  "radial-gradient(circle at 60% 50%, rgba(255,255,255,0.10) 0%, transparent 62%)",
              },
            }}
          >
            <Box
              sx={{
                width: { xs: 200, sm: 260, md: 340, lg: 390 },
                height: { xs: 200, sm: 260, md: 340, lg: 390 },
              }}
            >
              <GearAnimation size="100%" />
            </Box>
          </Box>
        </Paper>

        <Box ref={catalogSectionRef} sx={{ scrollMarginTop: 88 }}>
          <Paper
            elevation={0}
            sx={{
              p: { xs: 2, sm: 3 },
              mb: 3.5,
              borderRadius: 3.5,
            }}
          >
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2} alignItems={{ sm: "center" }}>
              <TextField
                fullWidth
                size="medium"
                placeholder="Введите артикул или название детали"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon sx={{ fontSize: 22, color: "primary.main" }} />
                    </InputAdornment>
                  ),
                }}
              />
              <FormControlLabel
                sx={{ whiteSpace: "nowrap", mr: 0 }}
                control={
                  <Switch
                    checked={inStockOnly}
                    onChange={(e) => { setInStockOnly(e.target.checked); setPage(1); }}
                  />
                }
                label="Только в наличии"
              />
            </Stack>
          </Paper>

          {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 2.5 }}>{error}</Alert>}

          {loading ? (
            <Stack alignItems="center" sx={{ py: 9 }}>
              <CircularProgress />
            </Stack>
          ) : items.length === 0 ? (
            <Alert severity="info" sx={{ borderRadius: 2.5 }}>Ничего не найдено по заданным условиям.</Alert>
          ) : (
            <>
              <Stack direction="row" justifyContent="space-between" alignItems="baseline" sx={{ mb: 2.5, px: 0.5 }}>
                <Typography variant="h6" sx={{ fontWeight: 700 }}>Запчасти</Typography>
                <Typography variant="body2" color="text.secondary">Найдено: {total}</Typography>
              </Stack>
              <Grid container spacing={{ xs: 2, sm: 2.5 }} justifyContent="center">
                {items.map((part) => (
                  <Grid item xs={12} sm={6} md={4} lg={3} key={part.id}>
                    <PartCard part={part} />
                  </Grid>
                ))}
              </Grid>

              <Stack alignItems="center" sx={{ mt: 5 }}>
                <Pagination
                  count={pageCount}
                  page={page}
                  onChange={(_, value) => setPage(value)}
                  color="primary"
                  shape="rounded"
                />
              </Stack>
            </>
          )}
        </Box>
      </Container>
    </>
  );
}

// Сборка ссылки на карточку товара в сторфронте Ozon.
// Публичные ссылки вида ozon.ru/product/.../ адресуются по SKU, а не по
// внутреннему product_id из Seller API — поэтому сначала пробуем SKU.
// Если SKU ещё не присвоен (товар только что синхронизирован), используем
// product_id через классический маршрут /context/detail/id/.
export function getOzonUrl(part) {
  if (!part) return null;
  if (part.ozon_sku) return `https://www.ozon.ru/product/${part.ozon_sku}/`;
  if (part.ozon_product_id) return `https://www.ozon.ru/context/detail/id/${part.ozon_product_id}/`;
  return null;
}

import { Box } from "@mui/material";

/**
 * Декоративная анимация для героя главной страницы: две сцепленные
 * шестерни, вращающиеся навстречу друг другу — визуальный эквивалент
 * "человека в движении" для тематики автозапчастей.
 * Уважает prefers-reduced-motion (анимация отключается).
 */
export default function GearAnimation({ size = 420 }) {
  return (
    <Box
      component="svg"
      viewBox="0 0 360 360"
      width={size}
      height={size}
      sx={{
        display: "block",
        filter: "drop-shadow(0 18px 34px rgba(2,12,25,0.35))",
        "@media (prefers-reduced-motion: no-preference)": {
          "& .gear-cw": { animation: "gear-spin-cw 22s linear infinite" },
          "& .gear-ccw": { animation: "gear-spin-ccw 15.7s linear infinite" },
        },
        "@keyframes gear-spin-cw": {
          from: { transform: "rotate(0deg)" },
          to: { transform: "rotate(360deg)" },
        },
        "@keyframes gear-spin-ccw": {
          from: { transform: "rotate(0deg)" },
          to: { transform: "rotate(-360deg)" },
        },
      }}
    >
      <defs>
        <linearGradient id="steelBody" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#EAF3FA" />
          <stop offset="45%" stopColor="#9CC1DE" />
          <stop offset="100%" stopColor="#3D6E93" />
        </linearGradient>
        <linearGradient id="steelBodySmall" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F4F9FC" />
          <stop offset="50%" stopColor="#AFD3EA" />
          <stop offset="100%" stopColor="#5B9BD5" />
        </linearGradient>
      </defs>

      {/* Большая шестерня — вращается по часовой */}
      <g className="gear-cw" transform="translate(148 190)">
        <g fill="url(#steelBody)">
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(0.0)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(25.714)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(51.429)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(77.143)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(102.857)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(128.571)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(154.286)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(180.0)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(205.714)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(231.429)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(257.143)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(282.857)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(308.571)" />
          <rect x="-7.5" y="-77" width="15" height="15" rx="1.5" transform="rotate(334.286)" />
        </g>
        <circle r="66" fill="url(#steelBody)" stroke="#1B3A5C" strokeWidth="1.5" />
        <circle r="44" fill="none" stroke="#1B3A5C" strokeWidth="1.5" opacity="0.35" />
        <circle r="20" fill="#12314F" />
        <circle r="20" fill="none" stroke="#1B3A5C" strokeWidth="1.5" />
        {[0, 90, 180, 270].map((deg) => (
          <rect
            key={deg}
            x="-3.5"
            y="-34"
            width="7"
            height="16"
            rx="2"
            fill="#12314F"
            opacity="0.45"
            transform={`rotate(${deg})`}
          />
        ))}
      </g>

      {/* Малая шестерня — вращается против часовой, сцеплена с большой */}
      <g className="gear-ccw" transform="translate(246 132)">
        <g fill="url(#steelBodySmall)">
          <rect x="-5.5" y="-49" width="11" height="11" rx="1.5" transform="rotate(0.0)" />
          <rect x="-5.5" y="-49" width="11" height="11" rx="1.5" transform="rotate(36.0)" />
          <rect x="-5.5" y="-49" width="11" height="11" rx="1.5" transform="rotate(72.0)" />
          <rect x="-5.5" y="-49" width="11" height="11" rx="1.5" transform="rotate(108.0)" />
          <rect x="-5.5" y="-49" width="11" height="11" rx="1.5" transform="rotate(144.0)" />
          <rect x="-5.5" y="-49" width="11" height="11" rx="1.5" transform="rotate(180.0)" />
          <rect x="-5.5" y="-49" width="11" height="11" rx="1.5" transform="rotate(216.0)" />
          <rect x="-5.5" y="-49" width="11" height="11" rx="1.5" transform="rotate(252.0)" />
          <rect x="-5.5" y="-49" width="11" height="11" rx="1.5" transform="rotate(288.0)" />
          <rect x="-5.5" y="-49" width="11" height="11" rx="1.5" transform="rotate(324.0)" />
        </g>
        <circle r="41" fill="url(#steelBodySmall)" stroke="#1B3A5C" strokeWidth="1.5" />
        <circle r="13" fill="#12314F" />
        <circle r="13" fill="none" stroke="#1B3A5C" strokeWidth="1.5" />
      </g>
    </Box>
  );
}

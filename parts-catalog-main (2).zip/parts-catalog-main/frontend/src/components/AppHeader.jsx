import {
  AppBar, Toolbar, Box, Button, Stack, IconButton, Container,
  Dialog, DialogTitle, DialogContent, IconButton as MuiIconButton,
  List, ListItem, ListItemIcon, ListItemText, Typography, Divider,
} from "@mui/material";
import { useNavigate, useLocation } from "react-router-dom";
import { useState } from "react";
import LightModeIcon from "@mui/icons-material/LightMode";
import DarkModeIcon from "@mui/icons-material/DarkMode";
import CloseIcon from "@mui/icons-material/Close";
import PhoneIcon from "@mui/icons-material/Phone";
import EmailIcon from "@mui/icons-material/Email";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import Logo from "./Logo";
import { useThemeMode } from "../ThemeModeContext";

// Контактные данные — плейсхолдеры, замените на реальные перед деплоем
const CONTACT_INFO = [
  { icon: PhoneIcon, label: "Телефон", value: "+7 (000) 000-00-00" },
  { icon: EmailIcon, label: "Email", value: "info@omegation.ru" },
  { icon: LocationOnIcon, label: "Адрес", value: "г. Москва, ул. Примерная, д. 1" },
  { icon: AccessTimeIcon, label: "Режим работы", value: "Пн–Пт: 9:00–18:00" },
];

function ContactsDialog({ open, onClose }) {
  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="xs">
      <DialogTitle sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", pr: 1 }}>
        Контакты
        <MuiIconButton onClick={onClose} size="small">
          <CloseIcon fontSize="small" />
        </MuiIconButton>
      </DialogTitle>
      <DialogContent sx={{ pb: 3 }}>
        <List disablePadding>
          {CONTACT_INFO.map((item, i) => (
            <ListItem key={item.label} disableGutters sx={{ py: 1.25 }}>
              <ListItemIcon sx={{ minWidth: 42, color: "primary.main" }}>
                <item.icon />
              </ListItemIcon>
              <ListItemText
                primary={item.label}
                secondary={item.value}
                primaryTypographyProps={{ variant: "caption", color: "text.secondary" }}
                secondaryTypographyProps={{ variant: "body1", sx: { fontWeight: 600, color: "text.primary" } }}
              />
            </ListItem>
          ))}
        </List>
        <Divider sx={{ my: 1.5 }} />
        <Typography variant="caption" color="text.secondary">
          Свяжитесь с нами любым удобным способом — ответим в течение рабочего дня.
        </Typography>
      </DialogContent>
    </Dialog>
  );
}

const NAV_LINKS = [
  { label: "О нас", path: "/about", type: "page" },
  { label: "Контакты", type: "modal" },
];

export default function AppHeader() {
  const navigate = useNavigate();
  const location = useLocation();
  const { mode, toggleMode } = useThemeMode();
  const isAdmin = location.pathname.startsWith("/admin");
  const [contactsOpen, setContactsOpen] = useState(false);

  return (
    <AppBar position="sticky" elevation={0}>
      <Container maxWidth="lg" disableGutters>
        <Toolbar
          sx={{
            minHeight: { xs: 58, sm: 66 },
            px: { xs: 1.5, sm: 3 },
            display: "grid",
            gridTemplateColumns: "1fr auto 1fr",
            alignItems: "center",
          }}
        >
          <Box />

          <Box
            sx={{
              cursor: isAdmin ? "default" : "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              py: 0.5,
            }}
            onClick={() => !isAdmin && navigate("/")}
          >
            <Logo height={28} color="#FFFFFF" />
          </Box>

          <Stack
            direction="row"
            spacing={{ xs: 0, sm: 0.5 }}
            alignItems="center"
            justifyContent="flex-end"
            sx={{ minWidth: 0 }}
          >
            {!isAdmin &&
              NAV_LINKS.map((link) => (
                <Button
                  key={link.label}
                  color="inherit"
                  size="small"
                  onClick={() =>
                    link.type === "modal" ? setContactsOpen(true) : navigate(link.path)
                  }
                  sx={{
                    color: "rgba(255,255,255,0.86)",
                    fontSize: { xs: "0.66rem", sm: "0.78rem" },
                    textTransform: "none",
                    minWidth: "auto",
                    px: { xs: 0.55, sm: 1.1 },
                    whiteSpace: "nowrap",
                    "&:hover": { color: "#FFFFFF", bgcolor: "rgba(255,255,255,0.08)" },
                  }}
                >
                  {link.label}
                </Button>
              ))}
            <IconButton
              onClick={toggleMode}
              color="inherit"
              size="small"
              aria-label="Переключить тему"
              sx={{
                ml: { xs: 0.15, sm: 0.5 },
                border: "1px solid rgba(255,255,255,0.18)",
                width: 30,
                height: 30,
                "&:hover": { bgcolor: "rgba(255,255,255,0.12)" },
              }}
            >
              {mode === "dark" ? <LightModeIcon sx={{ fontSize: 16 }} /> : <DarkModeIcon sx={{ fontSize: 16 }} />}
            </IconButton>
          </Stack>
        </Toolbar>
      </Container>

      <ContactsDialog open={contactsOpen} onClose={() => setContactsOpen(false)} />
    </AppBar>
  );
}

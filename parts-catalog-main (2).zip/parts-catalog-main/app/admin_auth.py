"""
Простая токен-авторизация для админки.
Сравнение токена выполняется через hmac.compare_digest, чтобы исключить
утечку времени выполнения (timing attack) при сравнении строк.
"""
import hmac
import os
from fastapi import Header, HTTPException, status

ADMIN_TOKEN = os.getenv("ADMIN_TOKEN")

if not ADMIN_TOKEN:
    raise RuntimeError(
        "ADMIN_TOKEN не задан в .env — сгенерируйте: openssl rand -hex 32"
    )

_ADMIN_TOKEN_BYTES = ADMIN_TOKEN.encode("utf-8")


def require_admin(authorization: str = Header(None)) -> None:
    if authorization is None or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Требуется заголовок Authorization: Bearer <token>",
        )
    token = authorization.removeprefix("Bearer ").strip()
    if not hmac.compare_digest(token.encode("utf-8"), _ADMIN_TOKEN_BYTES):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Неверный токен")

"""
Pydantic-схемы для админ-эндпоинтов.
"""
from typing import Optional, List
from pydantic import BaseModel, Field, field_validator

ALLOWED_URL_SCHEMES = ("http://", "https://")


class PartContentUpdate(BaseModel):
    name: Optional[str] = Field(None, max_length=500)
    description: Optional[str] = None
    brand: Optional[str] = Field(None, max_length=255)
    category_name: Optional[str] = Field(None, max_length=255)


class ImageReorderItem(BaseModel):
    url: str
    sort_order: int
    is_primary: bool = False


class ImageReorderRequest(BaseModel):
    images: List[ImageReorderItem]


class AddImageByUrlRequest(BaseModel):
    url: str
    set_as_primary: bool = False

    @field_validator("url")
    @classmethod
    def validate_url_scheme(cls, value: str) -> str:
        """Запрещает javascript:/data:/file: и другие опасные схемы —
        разрешены только обычные http/https ссылки на изображения."""
        if not value.lower().startswith(ALLOWED_URL_SCHEMES):
            raise ValueError("URL должен начинаться с http:// или https://")
        return value


class RevertToSyncRequest(BaseModel):
    confirm: bool = True
